/* polinomio.cpp */
#include"polinomio.h"

Polinomio CrearPolinomio(string poli) {
}

void MostrarPolinomio(Polinomio p) {

}

Polinomio SumarPolinomio(Polinomio &nuevoPol, Polinomio a, Polinomio b) {

}

Polinomio multiplicarPolinomio(Polinomio &nuevoPol, Polinomio a, Polinomio b) {

}
